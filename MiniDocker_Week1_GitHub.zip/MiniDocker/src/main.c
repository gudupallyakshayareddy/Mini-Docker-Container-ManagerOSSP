#include <stdio.h>
#include <string.h>

int main(void) {
    char command[100];

    printf("=====================================\n");
    printf("   Mini Docker Container Manager\n");
    printf("=====================================\n");
    printf("Type 'help' for commands\n");
    printf("Type 'exit' to quit\n\n");

    while (1) {
        printf("MiniDocker> ");

        if (fgets(command, sizeof(command), stdin) == NULL) {
            break;
        }

        command[strcspn(command, "\n")] = '\0';

        if (strcmp(command, "exit") == 0) {
            printf("Exiting Mini Docker...\n");
            break;
        } else if (strcmp(command, "help") == 0) {
            printf("\nAvailable Commands:\n");
            printf("help\n");
            printf("create <name>\n");
            printf("start <name>\n");
            printf("stop <name>\n");
            printf("list\n");
            printf("exit\n\n");
        } else if (strncmp(command, "create", 6) == 0) {
            printf("Container Created Successfully\n");
        } else if (strncmp(command, "start", 5) == 0) {
            printf("Container Started\n");
        } else if (strncmp(command, "stop", 4) == 0) {
            printf("Container Stopped\n");
        } else if (strcmp(command, "list") == 0) {
            printf("No Containers Available (Week 1 demo)\n");
        } else if (strlen(command) == 0) {
            /* Ignore empty input. */
        } else {
            printf("Unknown Command\n");
        }
    }

    return 0;
}
