# Week 1 Submission

Milestone: REPL Loop, Repository Setup, Makefile

Completed in this starter repository:
- Interactive REPL loop in `src/main.c`
- Makefile for build/run/clean
- README with project description and expected outcome
- Git-ready project structure
- `.gitignore`

After uploading to GitHub, add:
- Terminal screenshot showing `make`, `make run`, and the REPL
- GitHub repository screenshot
